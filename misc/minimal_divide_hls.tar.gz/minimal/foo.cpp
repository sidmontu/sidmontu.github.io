#include <ap_int.h>
#include <hls_stream.h>

using namespace hls;

void foo(
    stream<ap_uint<64> >& in,
    stream<ap_int<32> >& out
) {
#pragma HLS INTERFACE axis register both port=in
#pragma HLS INTERFACE axis register both port=out
#pragma HLS INTERFACE ap_ctrl_none port=return

    const unsigned DIV_U = 4;
    const int DIV_S = 4;

    ap_int<32> result;
    ap_uint<64> v = in.read();

    for (int j = 0; j < 4; j++) {
        ap_int<16> vv = v( (j+1)*16-1, j*16 );
        if (j == 0)
            result = vv;
        else
            result += vv;
    }
    out.write(result/DIV_U);
    out.write(result/DIV_S);
}

#ifdef EN_TB
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    const unsigned num_in = 1;
    const unsigned num_out = 2;

    stream<ap_uint<64> > in_stream("in_stream");
    stream<ap_int<32> > out_stream("out_stream");

    for (int i = 0; i < num_in; i++) {
        ap_uint<64> tmp = 0xfff5fffdfffafffc; // 4 x 16b signed ints ==> {-11,-3,-6,-4}
        in_stream.write(tmp);
    }

    foo(in_stream,out_stream);

    for (int i = 0; i < num_out; i++) {
        int v = (int)out_stream.read();
        printf("Received = 0x%x (= %d)\n",v,v);
    }

    return 0;
}

#endif




